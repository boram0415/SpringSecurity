package OAuthJWT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OAuthJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(OAuthJwtApplication.class, args);
	}

}
