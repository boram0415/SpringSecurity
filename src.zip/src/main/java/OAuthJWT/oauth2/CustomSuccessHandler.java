package OAuthJWT.oauth2;

import OAuthJWT.dto.CustomOAuth2User;
import OAuthJWT.dto.Token;
import OAuthJWT.jwt.JWTUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseCookie;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

/*로그인 성공 시 호출 페이지*/

@Component
@RequiredArgsConstructor
public class CustomSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

    private final JWTUtil jwtUtil;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        System.out.println("onAuthenticationSuccess start");
        //OAuth2User
        CustomOAuth2User customUserDetails = (CustomOAuth2User) authentication.getPrincipal();

        String username = customUserDetails.getUsername();

        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        Iterator<? extends GrantedAuthority> iterator = authorities.iterator();
        GrantedAuthority auth = iterator.next();
        System.out.println("auth = " + auth);
        String role = auth.getAuthority();

        // jwt 발급
        Token token = jwtUtil.createAccessToken(username, role);

        ResponseCookie responseCookie = ResponseCookie.from("refresh_token", token.getRefreshToken())
                .value(token.getRefreshToken())
                .httpOnly(true)
                .secure(true)
                .path("/")
                .sameSite("strict")
                .build();

        response.setHeader("Authorization", "Bearer " + token.getAccessToken());
        response.addHeader("Set-Cookie", responseCookie.toString());
        response.sendRedirect("http://localhost:8080/");

    }

    private Cookie createCookie(String key, String value) {

        Cookie cookie = new Cookie(key, value);
        cookie.setMaxAge(60*60*60);
        cookie.setSecure(true);
        cookie.setPath("/");
        cookie.setHttpOnly(true);
        return cookie;
    }


}
