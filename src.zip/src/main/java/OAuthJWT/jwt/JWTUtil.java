package OAuthJWT.jwt;

import OAuthJWT.dto.Token;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * JWT 토큰 발행 클래스
 * */
@Component
public class JWTUtil {

    private SecretKey accessSecretKey;
    private SecretKey refreshSecretKey;

    public JWTUtil(@Value("${spring.jwt.accessKey}") String accessKey
                ,@Value("${spring.jwt.refreshKey}") String refreshKey) {
        accessSecretKey = new SecretKeySpec(accessKey.getBytes(StandardCharsets.UTF_8), Jwts.SIG.HS256.key().build().getAlgorithm());
        refreshSecretKey = new SecretKeySpec(refreshKey.getBytes(StandardCharsets.UTF_8), Jwts.SIG.HS256.key().build().getAlgorithm());
        System.out.println("accessKey = " + accessKey);
        System.out.println("refresh = " + refreshKey);
    }


    public String getUsername(String token) {

        return Jwts.parser().verifyWith(accessSecretKey).build().parseSignedClaims(token).getPayload().get("username", String.class);
    }

    public String getRole(String token) {

        return Jwts.parser().verifyWith(accessSecretKey).build().parseSignedClaims(token).getPayload().get("role", String.class);
    }

    public Boolean isExpired(String token) {
        return Jwts.parser().verifyWith(accessSecretKey).build().parseSignedClaims(token).getPayload().getExpiration().before(new Date());
    }

    public Token createAccessToken(String userEmail, String role) {

        String accessToken = Jwts.builder()
                .claim("userEmail", userEmail)
                .claim("role", role)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + 30 * 60 * 1000)) // 30분
                .signWith(accessSecretKey)
                .compact();

        String refreshToken = Jwts.builder()
                .claim("userEmail", userEmail)
                .claim("role", role)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + 60*60*24*7)) // 일주일
                .signWith(refreshSecretKey)
                .compact();

        return Token.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .grantType(role)
                .build();
    }

    public String reCreationAccessToken(String userEmail, Object roles) {
        return Jwts.builder()
                .claim("userEmail",userEmail)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + 1800))
                .signWith(accessSecretKey)
                .compact();
    }





}
