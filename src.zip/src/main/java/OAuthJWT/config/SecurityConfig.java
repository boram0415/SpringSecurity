package OAuthJWT.config;


import OAuthJWT.dto.CustomOAuth2User;
import OAuthJWT.jwt.JWTFilter;
import OAuthJWT.jwt.JWTUtil;
import OAuthJWT.oauth2.CustomSuccessHandler;
import OAuthJWT.sevice.CustomOAuth2UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.util.HashSet;
import java.util.Set;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final CustomOAuth2UserService customOAuth2UserService;
    private final CustomSuccessHandler customSuccessHandler;
    private final JWTUtil jwtUtil;

    @Bean
    public SecurityFilterChain FilterChain(HttpSecurity http) throws Exception {

        //csrf disable
        http
                .csrf(AbstractHttpConfigurer::disable);

        //경로별 인가 작업
        http
                .authorizeHttpRequests((auth) -> auth
                        // authenticated() : 로그인 되어야 접근 가능 함
                        .requestMatchers("/loginForm","/user").permitAll()
                        .anyRequest().authenticated());

        //From 로그인 방식 disable
        http
                .formLogin((form) -> form
//                        .loginPage("/loginForm")
                        // redirect
//                        .successForwardUrl("/index")
                        .defaultSuccessUrl("/",true)
                        .failureUrl("/loginError")
                                .permitAll()
        );

        //HTTP Basic 인증 방식 disable
        http
                .httpBasic(AbstractHttpConfigurer::disable);

        //oauth2
        http
                .oauth2Login((auth) -> auth
                        .userInfoEndpoint((userInfoEndpointConfig -> userInfoEndpointConfig
                                .userService(customOAuth2UserService)))
                        .successHandler(customSuccessHandler));

        // JWTFilter 추가
        http
                .addFilterBefore(new JWTFilter(jwtUtil), UsernamePasswordAuthenticationFilter.class);

        //세션 설정 : STATELESS
        http
                .sessionManagement((session) -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        return http.build();
    }

//    private Set<GrantedAuthority> userAuthoritiesMapper(OAuth2User user) {
//        Set<GrantedAuthority> authorities = new HashSet<>(user.getAuthorities());
//        authorities.add(new SimpleGrantedAuthority());
//        return authorities;
//    }
}


